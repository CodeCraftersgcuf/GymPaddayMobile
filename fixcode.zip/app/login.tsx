import React, { useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Linking,
} from "react-native";
import { useTheme } from "@/contexts/themeContext";
import { COLORS, images } from "@/constants";
import { Image } from "expo-image";
import { validationSignInSchema } from "@/constants/validation";
import { Formik } from "formik";
import { Link, useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import FloatingLabelInput from "@/components/login/FloatingLabelInput";
import ThemeText from "@/components/ThemedText";
import ThemedView from "@/components/ThemedView";

// ✅ Import toast & mutation
import Toast from "react-native-toast-message";
import { useMutation } from "@tanstack/react-query";
import { loginUser } from "@/utils/mutations/auth";

import * as SecureStore from 'expo-secure-store';
import AsyncStorage from "@react-native-async-storage/async-storage";

const Login = () => {const [checkingAuth, setCheckingAuth] = React.useState(true);


  const route = useRouter();
  const { dark } = useTheme();
  const termsUrl = "https://gympaddy.com/terms";
  const privacyUrl = "https://gympaddy.com/privacy";
useEffect(() => {
  const checkAuth = async () => {
    const hasSeenOnboarding = await AsyncStorage.getItem("hasSeenOnboarding");

    // 🚫 If onboarding hasn't been seen, don't auto-login!
    if (!hasSeenOnboarding) {
      console.log("⛔ Onboarding not yet completed. Showing login.");
      setCheckingAuth(false);
      return;
    }

    const token = await SecureStore.getItemAsync("auth_token");
    const userData = await SecureStore.getItemAsync("user_data");

    if (token && userData) {
      console.log("✅ Auto-logging in...");
      route.replace("/(tabs)");
    } else {
      setCheckingAuth(false); // show login UI
    }
  };

  checkAuth();
}, []);


  const mutation = useMutation({
    mutationFn: loginUser,
    onSuccess: async (data) => {
      console.log("🎉 Login Success:", data);

      if (data?.access_token) {
        // ✅ Save token securely with error handling
        try {
          await SecureStore.setItemAsync("auth_token", data.access_token);
          await SecureStore.setItemAsync("user_data", JSON.stringify(data.user));
          await SecureStore.setItemAsync("user_id", data.user.id.toString());
          await SecureStore.setItemAsync("username", data.user.username || "");
          
          // ✅ Mark that onboarding was completed
          await AsyncStorage.setItem("hasSeenOnboarding", "true");
          
          console.log("✅ User data and token saved successfully");
        } catch (storageError) {
          console.error("❌ Failed to save auth data:", storageError);
          Toast.show({
            type: "error",
            text1: "Storage Error",
            text2: "Failed to save login data. Please try again.",
          });
          return;
        }

        Toast.show({
          type: "success",
          text1: "Login Successful",
          text2: `Welcome back, ${data.user?.fullname || 'user'}!`,
        });

        // Use replace instead of push to prevent back navigation
        route.replace("/(tabs)");
      } else {
        Toast.show({
          type: "error",
          text1: "Login Failed",
          text2: "Invalid response from server.",
        });
      }
    },
    onError: (error: any) => {
      console.error("❌ Login Error:", error);
      Toast.show({
        type: "error",
        text1: "Login Failed",
        text2: error?.message || "Something went wrong",
      });
    },
  });

  const handleLogin = (values: { email: string; password: string }) => {
    console.log("Login Data:", values);
    mutation.mutate({ data: values });
  };
if (checkingAuth) {
  return (
    <SafeAreaView style={[styles.container, { justifyContent: "center", alignItems: "center" }]}>
      <Text style={{ fontSize: 16, color: dark ? "white" : "black" }}>
        Checking authentication...
      </Text>
    </SafeAreaView>
  );
}

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
        <ThemedView style={{ flex: 1 }}>
        <LinearGradient
          colors={["#940304", "#840000"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ height: 150 }}
        />

        <ThemedView
          style={{
            marginHorizontal: 20,
            borderRadius: 20,
            padding: 10,
            elevation: 5,
            shadowColor: dark ? "white" : "black",
            transform: [{ translateY: -50 }],
          }}
        >
          {/* Logo */}
          <ThemedView
            darkColor="transparent"
            style={{
              alignSelf: "center",
              backgroundColor: "white",
              transform: [{ translateY: -60 }],
              borderRadius: 10,
              elevation: 5,
              padding: 10,
            }}
          >
            <Image
              source={images.logo}
              style={{
                width: 70,
                height: 70,
              }}
            />
          </ThemedView>

          <ThemedView
            darkColor="transparent"
            style={{ transform: [{ translateY: -40 }] }}
          >
            <ThemeText
              style={{
                fontSize: 24,
                fontWeight: "bold",
                textAlign: "center",
              }}
            >
              Login
            </ThemeText>
            <ThemeText
              style={{
                fontSize: 14,
                color: dark ? COLORS.white : "gray",
                textAlign: "center",
              }}
            >
              Login to your account
            </ThemeText>

            <KeyboardAvoidingView
              behavior={Platform.OS === "ios" ? "padding" : "height"}
            >
              <Formik
                initialValues={{ email: "", password: "" }}
                validationSchema={validationSignInSchema}
                onSubmit={handleLogin}
              >
                {({
                  handleChange,
                  handleBlur,
                  handleSubmit,
                  values,
                  errors,
                  touched,
                }) => (
                  <ThemedView darkColor="transparent" style={styles.card}>
                    <FloatingLabelInput
                      label="Email"
                      value={values.email}
                      onChangeText={handleChange("email")}
                      onBlur={handleBlur("email")}
                      error={
                        touched.email && errors.email ? errors.email : ""
                      }
                      keyboardType="email-address"
                      autoComplete="off"
                    />

                    <FloatingLabelInput
                      label="Password"
                      autoComplete="off"
                      value={values.password}
                      onChangeText={handleChange("password")}
                      onBlur={handleBlur("password")}
                      error={
                        touched.password && errors.password
                          ? errors.password
                          : ""
                      }
                      isPassword={true}
                    />

                    {/* Forgot Password */}
                    <TouchableOpacity onPress={() => route.push("/forgetpassword")}>
                      <ThemeText style={styles.forgotPassword}>
                        Forgot Password?
                      </ThemeText>
                    </TouchableOpacity>

                    {/* Login Button */}
                    <Pressable
                      onPress={() => handleSubmit()}
                      style={{
                        backgroundColor: "#940304",
                        paddingVertical: 15,
                        borderRadius: 10,
                      }}
                    >
                      <ThemeText
                        style={{
                          textAlign: "center",
                          color: "white",
                          fontWeight: "500",
                          fontSize: 16,
                        }}
                      >
                        {mutation.isPending ? "Logging in..." : "Login"}
                      </ThemeText>
                    </Pressable>

                    {/* Register Redirect */}
                    <Link
                      href={"/register"}
                      style={{ paddingVertical: 15, borderRadius: 10 }}
                    >
                      <ThemeText style={styles.registerText}>Register</ThemeText>
                    </Link>
                    <Link
                      href={"/(tabs)"}
                      style={{ paddingVertical: 15, borderRadius: 10 }}
                    >
                    </Link>
                  </ThemedView>
                )}
              </Formik>
            </KeyboardAvoidingView>
          </ThemedView>
        </ThemedView>

        <ThemedView style={{ flex: 1, justifyContent: "flex-end" }}>
          <ThemeText
            style={{ textAlign: "center", paddingHorizontal: 30, paddingBottom: 20 }}
          >
            By continuing you agree to gym paddy’s{" "}
            <ThemeText style={{ color: "red" }} onPress={() => Linking.openURL(termsUrl)}>
              terms of use
            </ThemeText>{" "}
            and{" "}
            <ThemeText style={{ color: "red" }} onPress={() => Linking.openURL(privacyUrl)}>
              privacy policy
            </ThemeText>
            .
          </ThemeText>
        </ThemedView>
        </ThemedView>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  card: {
    marginTop: 20,
    paddingHorizontal: 15,
  },
  forgotPassword: {
    color: "#940304",
    textAlign: "right",
    marginBottom: 16,
    fontSize: 14,
  },
  registerText: {
    color: "#940304",
    textAlign: "center",
    fontSize: 14,
    marginTop: 16,
  },
});

export default Login;
